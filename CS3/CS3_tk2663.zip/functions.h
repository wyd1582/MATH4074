
double ran2_mod(long *idum);
double invNormal(double p);
double gamrand(double alpha, double beta, long *idum);
//void randZ();
